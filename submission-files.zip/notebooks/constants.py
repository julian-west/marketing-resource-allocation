"""
File to define constants
"""

DATA_FOLDER = "../data"
VISUALISATION_FOLDER = "../report/visualisations"
RESULTS_FOLDER = "../report/results"
BRAND_COLORS = ["#0071bc", "#e7b800", "#d4145a"]

